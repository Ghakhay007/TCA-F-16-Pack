
How to Install Mods If You Don't Know how.
1) Right click on your TCA in steam and open properties
2) Click on installed files then click on Browse
3) If you don't see a folder called Mods right click and make a new folder called Mods
4) Drag or Copy and Paste the mod You'd like to install into the Mods folder
5) Launch TCA and type in onlytheharrier

Credits:
F-16A Model Made By taktischesgenie/ghaaaaa
Json Made By Black Mario
Json tweaks by Caboose/Crepe
and animation and loadout help by Viper Zero

Special thanks to:
Nuclear Stonk for help with the creation of this project

Enjoy this aircraft!

Updates:
V0.2
Fixes:
CockpitCam height and audio fixed
Lots of Json tweaking resulting in a more realistic Flight Model (thanks to crepe)
Wheels bouncing on takeoff fixed
changed some pylons to be hidden without any ordnance with the exception of those with fuel tanks
Merged FuelTanks and F-16 to be one single package

V0.3
added emissive lights to cockpit

V0.4
fixed landing gear orientation

V0.5
added new cockpit detail

V0.6
Fixed Wingtip pylon orientation and canopy transparency

V0.7
New cockpit details loadout changes and a few tweaks

V0.8
Flight Model revamp by Crepe
New F-16A Anniversary Edition (atm only a grey paintscheme new variants later)
Other itty bitty changes i dont remember

V0.9 Tactical Advantage
Probably the biggest update for the F-16 to date
Includes brand new variants
F-16A Cockpit improved
F-16AM new Danish MLU variant with cockpit
F-16C Block 40 latest and greatest with Lantirn + Navpod capability with cockpit
Completely reworked loadouts
and more

V1.0 Falcon GMS
cockpit fixes
it actually works now
krayp satisfied
life complete